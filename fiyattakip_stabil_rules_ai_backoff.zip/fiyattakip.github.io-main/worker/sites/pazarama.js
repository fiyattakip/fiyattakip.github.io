// worker/sites/pazarama.js
// Not: HTML değişken. Öncelik JSON-LD/meta fiyat. Bu modül basit bir yedek plan.
// Eğer fiyat bulunamazsa worker/common.js genel extractor devreye girer.
export function normalizeUrl(u){ return u; }
export function pickLink($){ 
  // arama sayfasında ürün linki yakalamak zor olabiliyor; şimdilik null.
  return null;
}
