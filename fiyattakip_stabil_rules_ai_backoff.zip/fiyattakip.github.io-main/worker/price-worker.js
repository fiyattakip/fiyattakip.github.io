// worker/price-worker.js (Node 18+)
// GitHub Actions çalıştırır. Firestore Admin ile yazar.
// Not: Sitelerin HTML yapısı değişebilir. Burada “meta/JSON-LD” ağırlıklı okunur.

import admin from "firebase-admin";
import fetch from "node-fetch";
import * as cheerio from "cheerio";

function mustEnv(name){
  const v = process.env[name];
  if (!v) throw new Error(`Missing env: ${name}`);
  return v;
}

const svc = JSON.parse(mustEnv("FIREBASE_SERVICE_ACCOUNT_JSON"));
admin.initializeApp({ credential: admin.credential.cert(svc) });
const db = admin.firestore();
const CHECK_INTERVAL_MS = Number(process.env.CHECK_INTERVAL_MS || 60*60*1000); // default 60dk
const COOLDOWN_ON_BLOCK_MS = Number(process.env.COOLDOWN_ON_BLOCK_MS || 12*60*60*1000); // default 12s
const COOLDOWN_ON_OTHER_ERR_MS = Number(process.env.COOLDOWN_ON_OTHER_ERR_MS || 6*60*60*1000); // default 6s

function parseTime(v){
  if (!v) return null;
  if (typeof v === "number") return v;
  const t = Date.parse(v);
  return Number.isFinite(t) ? t : null;
}

const SITES = [
  { key:"trendyol", name:"Trendyol" },
  { key:"hepsiburada", name:"Hepsiburada" },
  { key:"n11", name:"N11" },
  { key:"amazontr", name:"Amazon TR" },
  { key:"pazarama", name:"Pazarama" },
  { key:"ciceksepeti", name:"ÇiçekSepeti" },
  { key:"idefix", name:"idefix" },
];

function sleep(ms){ return new Promise(r=>setTimeout(r, ms)); }

function normPriceTry(str){
  if (!str) return null;
  const s = String(str).replace(/[^\d.,]/g,"").replace(/\./g,"").replace(",",".");
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

function pickJsonLdPrice($){
  const scripts = $('script[type="application/ld+json"]').toArray();
  for (const s of scripts){
    const txt = $(s).text();
    try{
      const j = JSON.parse(txt);
      const arr = Array.isArray(j) ? j : [j];
      for (const o of arr){
        const offers = o?.offers;
        if (offers){
          const offArr = Array.isArray(offers) ? offers : [offers];
          for (const ofr of offArr){
            const p = ofr?.price || ofr?.lowPrice || ofr?.highPrice;
            const n = normPriceTry(p);
            if (n) return n;
          }
        }
      }
    }catch{}
  }
  return null;
}

function pickMetaPrice($){
  const metaProps = [
    'meta[property="product:price:amount"]',
    'meta[property="og:price:amount"]',
    'meta[name="price"]',
    'meta[itemprop="price"]',
  ];
  for (const sel of metaProps){
    const v = $(sel).attr("content");
    const n = normPriceTry(v);
    if (n) return n;
  }
  return null;
}

async function fetchHtml(url){
  const res = await fetch(url, {
    headers:{
      "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125 Safari/537.36",
      "Accept":"text/html,application/xhtml+xml"
    }
  });
  const text = await res.text();
  return { ok: res.ok, status: res.status, text };
}

async function extractPrice(url){
  const { ok, status, text } = await fetchHtml(url);
  if (!ok) return { price:null, status };

  const $ = cheerio.load(text);
  let price = pickJsonLdPrice($) || pickMetaPrice($);

  // son çare: sayfadaki TL desenleri (riskli)
  if (!price){
    const body = $("body").text().slice(0, 200000);
    const m = body.match(/(\d{1,3}(\.\d{3})*|\d+)(,\d{2})?\s*TL/);
    if (m) price = normPriceTry(m[0]);
  }
  return { price, status };
}

// Search intent resolver (çok basit): site arama linkinden ilk ürün URL’sini bulmaya çalışır.
// Not: Her sitenin arama HTML’i farklı. Burada “en basit” yaklaşım var.
async function resolveSearchToProduct(siteKey, query){
  // Minimal: site arama sayfasını aç → ilk ürün linkini yakala (her zaman tutmayabilir)
  const build = {
    trendyol: `https://www.trendyol.com/sr?q=${encodeURIComponent(query)}`,
    hepsiburada: `https://www.hepsiburada.com/ara?q=${encodeURIComponent(query)}`,
    n11: `https://www.n11.com/arama?q=${encodeURIComponent(query)}`,
    amazontr: `https://www.amazon.com.tr/s?k=${encodeURIComponent(query)}`,
    pazarama: `https://www.pazarama.com/arama?q=${encodeURIComponent(query)}`,
    ciceksepeti: `https://www.ciceksepeti.com/arama?query=${encodeURIComponent(query)}`,
    idefix: `https://www.idefix.com/arama/?q=${encodeURIComponent(query)}`
  }[siteKey];

  if (!build) return null;

  const { ok, text } = await fetchHtml(build);
  if (!ok) return null;

  const $ = cheerio.load(text);

  // genel link yakalama (siteye göre değişir)
  const anchors = $("a[href]").toArray().slice(0, 400);
  for (const a of anchors){
    const href = $(a).attr("href") || "";
    const abs = href.startsWith("http") ? href : new URL(href, build).toString();

    // basit filtre: ürün sayfası olabilecek linkler
    if (siteKey === "trendyol" && abs.includes("/p-")) return abs;
    if (siteKey === "hepsiburada" && abs.includes(".com/") && abs.includes("-p-")) return abs;
    if (siteKey === "n11" && abs.includes("/urun/")) return abs;
    if (siteKey === "amazontr" && abs.includes("/dp/")) return abs;
    if (siteKey === "pazarama" && abs.includes("/urun/")) return abs;
    if (siteKey === "ciceksepeti" && abs.includes("/p/")) return abs;
    if (siteKey === "idefix" && abs.includes("/")) {
      // idefix ürün linkleri değişken, kaba bırakıyoruz:
      if (!abs.includes("/arama")) return abs;
    }
  }
  return null;
}

async function main(){
  // users/*/favorites/*
  const usersSnap = await db.collection("users").get();
  console.log("users:", usersSnap.size);

  for (const u of usersSnap.docs){
    const uid = u.id;
    const favsRef = db.collection("users").doc(uid).collection("favorites");
    const favsSnap = await favsRef.get();

    for (const f of favsSnap.docs){
      const fav = f.data();
      const favId = f.id;

      try{
        // 1) Search intent ise resolve et
        if (fav.type === "search" && !fav.resolved){
          const url = await resolveSearchToProduct(fav.siteKey, fav.query);
          if (url){
            await favsRef.doc(favId).update({
              resolved: true,
              productUrl: url,
              productTitle: fav.productTitle || fav.query
            });
            console.log("resolved", uid, favId, url);
          } else {
            console.log("resolve failed", uid, favId);
            continue; // resolve yoksa fiyat çekmeyelim
          }
          await sleep(800);
        }

        // 2) fiyat çek
        const productUrl = (fav.productUrl || "").trim();
        if (!productUrl) continue;

        // cache / cooldown
        const nowMs = Date.now();
        const lastCheckedMs = parseTime(fav.lastCheckedAt);
        const cooldownMs = parseTime(fav.cooldownUntil);
        if (cooldownMs && nowMs < cooldownMs){
          // cooldown aktif
          continue;
        }
        if (lastCheckedMs && (nowMs - lastCheckedMs) < CHECK_INTERVAL_MS){
          continue;
        }

        const { price, status } = await extractPrice(productUrl);

        // lastCheckedAt her denemede güncellensin
        await favsRef.doc(favId).update({
          lastCheckedAt: new Date(nowMs).toISOString(),
          error: null,
          cooldownUntil: null
        }).catch(()=>{});

        if (!price){
          // blok / koruma ihtimali: 403/429/503 gibi
          const s = Number(status||0);
          if ([403,429,503].includes(s)){
            const cd = new Date(nowMs + COOLDOWN_ON_BLOCK_MS).toISOString();
            await favsRef.doc(favId).update({
              error: `FETCH_BLOCK_${s}`,
              cooldownUntil: cd
            }).catch(()=>{});
          }else{
            const cd = new Date(nowMs + COOLDOWN_ON_OTHER_ERR_MS).toISOString();
            await favsRef.doc(favId).update({
              error: `PRICE_NOT_FOUND${s?("_"+s):""}`,
              cooldownUntil: cd
            }).catch(()=>{});
          }
          console.log("price not found", uid, favId, status);
          continue;
        }
        const priceHistory = Array.isArray(fav.priceHistory) ? fav.priceHistory.slice() : [];
        const legacyHistory = Array.isArray(fav.history) ? fav.history.slice() : [];

        // Normalize priceHistory to [{t:number(ms), p:number}]
        const ph = priceHistory
          .map(x=>({ t:Number(x.t||0), p:Number(x.p||0) }))
          .filter(x=>Number.isFinite(x.t) && Number.isFinite(x.p) && x.t>0 && x.p>0)
          .sort((a,b)=>a.t-b.t);

        const last = ph.length ? ph[ph.length-1].p : null;
        if (last != null && Number(last) === Number(price)){
          continue; // değişmediyse ekleme yok
        }

        ph.push({ t: Date.now(), p: Number(price) });

        // legacy history de tut (geriye uyum için)
        legacyHistory.push({ t: new Date().toISOString(), p: Number(price) });
        // yüzde düşüş kontrol (son 2)
        let drop = null;
        if (ph.length >= 2){
          const prev = ph[ph.length-2]?.p;
          const cur = ph[ph.length-1]?.p;
          if (prev && cur && cur < prev){
            drop = ((prev - cur) / prev) * 100;
          }
        }

        await favsRef.doc(favId).update({
          lastPrice: Number(price),
          priceHistory: ph,
          history: legacyHistory
        });
        if (drop != null && drop >= 10){
          console.log("DROP >=10%", uid, favId, drop.toFixed(1));
          // İstersen buraya FCM ekleriz (bir sonraki adım).
        }

        await sleep(900);
      }catch(e){
        console.log("err", uid, favId, e?.message || e);
      }
    }
  }
}

main().catch(e=>{
  console.error(e);
  process.exit(1);
});