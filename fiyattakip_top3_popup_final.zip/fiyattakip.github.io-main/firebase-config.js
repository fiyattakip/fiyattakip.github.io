// 🔴 Burayı Firebase Console > Project settings > Your apps (Web) kısmından aldığın config ile doldur.
// Bu dosya repoda durur ama secret değildir (Firebase web config genelde public sayılır).
// ÖNEMLİ: Domain kısıtlamalarını Firebase/Google Cloud'da yap.

export const firebaseConfig = {
  apiKey: "AIzaSyBcXkVFQzB2XtxO7wqnbXhzM1Io54zCsBI",
  authDomain: "fiyattakip-ttoxub.firebaseapp.com",
  projectId: "fiyattakip-ttoxub",
  storageBucket: "fiyattakip-ttoxub.firebasestorage.app",
  messagingSenderId: "105868725844",
  appId: "1:105868725844:web:fc04f5a08e708916e727c1"
};
